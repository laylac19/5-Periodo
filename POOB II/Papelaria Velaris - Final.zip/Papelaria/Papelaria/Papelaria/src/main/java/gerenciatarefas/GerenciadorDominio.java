/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gerenciatarefas;

import dao.ClienteDAO;
import dao.ConexaoHibernate;
import dao.FuncionarioDAO;
import dao.GenericDAO;
import dao.PedidoDAO;
import dao.ProdutoDAO;
import dominio.Cliente;
import dominio.Funcionario;
import dominio.ItemPedido;
import dominio.Pedido;
import dominio.Produto;

import javax.swing.*;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Date;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author layla
 */
public class GerenciadorDominio {

    private GenericDAO genDao;
    private FuncionarioDAO funDao;
    private ClienteDAO cliDao;
    private PedidoDAO pedDao;
    private ProdutoDAO prodDao;

    public GerenciadorDominio() throws ClassNotFoundException, SQLException {
        // ABRIR A CONEXAO HIBERNATE
        ConexaoHibernate.getSessionFactory();

        genDao = new GenericDAO();
        funDao = new FuncionarioDAO();
        cliDao = new ClienteDAO();
        pedDao = new PedidoDAO();
        prodDao = new ProdutoDAO();
    }

    // FUNÇÃO GENÉRICA
    public List listar(Class classe) throws ClassNotFoundException, SQLException {
        return genDao.listar(classe);
    }

    public void inserirCliente(String nome, String sobrenome, char sexo, String cpf, Date dtNasc,
            String cep, String logradouro, int num, String bairro, String complemento,
            String referencia, String cidade, String celular, String email) throws ClassNotFoundException, SQLException {

        Cliente cli = new Cliente(nome, sobrenome, sexo, cpf, dtNasc, cep, logradouro, num, bairro, complemento,
                referencia, cidade, celular, email);

        cliDao.inserir(cli);
    }

    public void inserirFuncionario(String nome, String sobrenome, char sexo,
            String cpf, Date dtNasc, String celular, float salario, String email) throws ClassNotFoundException, SQLException {

        Funcionario fun = new Funcionario(nome, sobrenome, sexo, cpf, dtNasc, celular, salario, email);

        funDao.inserir(fun);
    }

    public void inserirProduto(String descricao, Double valor) throws ClassNotFoundException, SQLException {

        Produto prod = new Produto(descricao, valor);

        prodDao.inserir(prod);
    }

    public int inserirPedido(Cliente cli, Funcionario fun, JTable tblPedidos) throws ClassNotFoundException, SQLException {
        Pedido ped = new Pedido(new Date(), 0, cli, fun);
        float valorTotal = 0;

        List<ItemPedido> lista = ped.getItensPedido();

        int tam = tblPedidos.getRowCount();
        if (tam > 0) {
            for (int lin = 0; lin < tam; lin++) {
                int col = 0;
                Produto produto = (Produto) tblPedidos.getValueAt(lin, col++);
                int qtde = (int) tblPedidos.getValueAt(lin, col++);

                ItemPedido item = new ItemPedido(produto, ped, qtde);
                lista.add(item);
                valorTotal = (float) (valorTotal + produto.getValor() * qtde);
            }
            ped.setValorTotal(valorTotal);
            genDao.inserir(ped);
            return ped.getIdPedido();
        } else {
            return -1;
        }
    }

    public void alterarCliente(Cliente cli, String nome, String sobrenome, char sexo, String cpf, Date dtNasc,
            String cep, String logradouro, int num, String bairro, String complemento,
            String referencia, String cidade, String celular, String email) throws ClassNotFoundException, SQLException {
        cli.setNome(nome);
        cli.setSobrenome(sobrenome);
        cli.setSexo(sexo);
        cli.setCpf(cpf);
        cli.setDtNasc(dtNasc);
        cli.setCep(cep);
        cli.setLogradouro(logradouro);
        cli.setNum(num);
        cli.setBairro(bairro);
        cli.setComplemento(complemento);
        cli.setReferencia(referencia);
        cli.setCidade(cidade);
        cli.setCelular(celular);
        cli.setEmail(email);

        cliDao.alterar(cli);
    }

    public void alterarFuncionario(Funcionario fun, String nome, String sobrenome, char sexo,
            String cpf, Date dtNasc, String celular, float salario, String email) throws ClassNotFoundException, SQLException {

        fun.setNome(nome);
        fun.setSobrenome(sobrenome);
        fun.setSexo(sexo);
        fun.setCpf(cpf);
        fun.setDtNasc(dtNasc);
        fun.setCelular(celular);
        fun.setSalario(salario);
        fun.setEmail(email);

        funDao.alterar(fun);
    }

    public void alterarProduto(Produto prod, String descricao, Double valor) throws ClassNotFoundException, SQLException {
        prod.setDescricao(descricao);
        prod.setValor(valor);

        prodDao.alterar(prod);
    }

    // FUNÇÃO GENÉRICA
    public void excluir(Object obj) throws ClassNotFoundException, SQLException {
        genDao.excluir(obj);
    }

    public List<Cliente> pesquisarCliente(String pesq, int tipo) throws ClassNotFoundException, SQLException {
        switch (tipo) {
            case 0:
                return cliDao.pesquisarPorNome(pesq);
            case 1:
                return cliDao.pesquisarPorSobrenome(pesq);
            case 2:
                return cliDao.pesquisarCpf(pesq);
            default:
                return null;
        }
    }

    public List<Funcionario> pesquisarFuncionario(String pesq, int tipo) throws ClassNotFoundException, SQLException {
        switch (tipo) {
            case 0:
                return funDao.pesquisarPorId(pesq);
            case 1:
                return funDao.pesquisarPorNome(pesq);
            case 2:
                return funDao.pesquisarPorSobrenome(pesq);
            default:
                return null;
        }
    }

    public List<Produto> pesquisarProduto(int tipo, String pesq) throws ClassNotFoundException, SQLException {
        switch (tipo) {
            case 0:
                return prodDao.pesquisarPorId(pesq);
            case 1:
                return prodDao.pesquisarPorDescricao(pesq);
            default:
                return null;
        }
    }

    public List<Pedido> pesquisarPedido(int tipo, String pesq) {
        List<Pedido> lista = null;

        switch (tipo) {
            case 0:
                lista = pedDao.pesquisarPorID(pesq);
                break;
            case 1:
                lista = pedDao.pesquisarPorCliente(pesq);
                break;
            case 2:
                lista = pedDao.pesquisarPorFuncionario(pesq);
                break;
            case 3:
                // Verificar se está no formato MM/YYYY
                String vetor[] = pesq.split("/");
                if (vetor.length == 2) {
                    lista = pedDao.pesquisarPorMes(pesq);
                } else {
                    throw new NumberFormatException("Usar o formato MÊS/ANO: MM/YYYY");
                }
                break;
        }
        return lista;
    }

    public void relGroupBy(JTable tabela, int tipo) throws Exception {
        List<Object[]> lista = null;
        Cliente cli = null;

        // Limpa a tabela
        ((DefaultTableModel) tabela.getModel()).setRowCount(0);

        switch (tipo) {
            case 'B':
                lista = cliDao.contPorBairro();
                break;
            case 'M':
                lista = pedDao.valorPorMes();
                break;
            case 'C':
                lista = pedDao.valorPorCliente();
                break;
            case 'F':
                lista = pedDao.valorPorFuncionario();
                break;
        }

        NumberFormat formato = NumberFormat.getCurrencyInstance();
        // Percorrer a LISTA
        if (lista != null) {

            for (Object[] obj : lista) {
                switch (tipo) {
                    case 'M':
                        obj[0] = obj[0].toString() + "/" + obj[1].toString();
                        obj[1] = formato.format(Double.parseDouble(obj[2].toString()));
                        break;
                    case 'C':
                        obj[1] = formato.format(Double.parseDouble(obj[1].toString()));
                        break;
                    case 'F':
                        obj[1] = formato.format(Double.parseDouble(obj[1].toString()));
                        break;

                }

                ((DefaultTableModel) tabela.getModel()).addRow(obj);
            }

        }
    }
}
