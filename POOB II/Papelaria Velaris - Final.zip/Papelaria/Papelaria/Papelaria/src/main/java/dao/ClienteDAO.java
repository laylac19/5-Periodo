/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dominio.Cliente;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 *
 * @author layla
 */
public class ClienteDAO extends GenericDAO {

    private List<Cliente> pesquisar(String pesq, int tipo) {
        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Cliente.class);

            Root tabela = consulta.from(Cliente.class);

            Predicate restricoes = null;
            switch (tipo) {
                case 1:
                    restricoes = builder.like(tabela.get("nome"), pesq + "%");
                    break;

                case 2:
                    restricoes = builder.like(tabela.get("sobrenome"), pesq + "%");
                    break;

                case 3:
                    restricoes = builder.like(tabela.get("cpf"), pesq + "%");
                    break;
            }

            consulta.where(restricoes);
            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }

    public List<Cliente> pesquisarPorNome(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 1);
    }

    public List<Cliente> pesquisarPorSobrenome(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 2);
    }

    public List<Cliente> pesquisarCpf(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 3);
    }

    public List contPorBairro() {

        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Object[].class);
            Root tabela = consulta.from(Cliente.class);

            consulta.multiselect(tabela.get("bairro"), builder.count(tabela.get("idCliente")));
            consulta.groupBy(tabela.get("bairro"));

            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }
}
