/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dominio.Produto;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 *
 * @author 1547816
 */
public class ProdutoDAO extends GenericDAO {

//    public List<Produto> listar() throws ClassNotFoundException, SQLException {
//        return null;
//    }
    private List<Produto> pesquisar(String pesq, int tipo) {
        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Produto.class);

            Root tabela = consulta.from(Produto.class);

            Predicate restricoes = null;
            switch (tipo) {
                case 1:
                    int id = Integer.parseInt(pesq);
                    restricoes = builder.equal(tabela.get("idProduto"), id);
                    break;
                case 2:
                    restricoes = builder.like(tabela.get("descricao"), pesq + "%");
                    break;
            }

            consulta.where(restricoes);
            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }

    public List<Produto> pesquisarPorId(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 1);
    }

    public List<Produto> pesquisarPorDescricao(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 2);
    }
}
