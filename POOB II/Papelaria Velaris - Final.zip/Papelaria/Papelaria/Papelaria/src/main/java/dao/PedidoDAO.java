/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dominio.Pedido;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 *
 * @author layla
 */
public class PedidoDAO extends GenericDAO {

    private List<Pedido> pesquisar(String pesq, int tipo) {
        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Pedido.class);

            Root tabela = consulta.from(Pedido.class);

            // Mudar o FETCH 
            tabela.fetch("itensPedido", JoinType.INNER);

            consulta.distinct(true);

            Predicate restricoes = null;
            switch (tipo) {
                case 0:
                    int id = Integer.parseInt(pesq);
                    restricoes = builder.equal(tabela.get("idPedido"), id);
                    break;
                case 1:
                    restricoes = builder.like(tabela.get("cliente").get("nome"), pesq + "%");
                    break;

                case 2:
                    restricoes = builder.like(tabela.get("funcionario").get("nome"), pesq + "%");
                    break;

                case 3:
                    String vetor[] = pesq.split("/");
                    Expression exprMes = builder.function("month", Integer.class, tabela.get("dataPedido"));
                    Expression exprAno = builder.function("year", Integer.class, tabela.get("dataPedido"));
                    restricoes = builder.and(
                            builder.equal(exprMes, vetor[0]),
                            builder.equal(exprAno, vetor[1])
                    );
                    break;
            }

            consulta.where(restricoes);
            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }

    public List<Pedido> pesquisarPorID(String pesq) {
        return pesquisar(pesq, 0);
    }

    public List<Pedido> pesquisarPorCliente(String pesq) {
        return pesquisar(pesq, 1);
    }

    public List<Pedido> pesquisarPorFuncionario(String pesq) {
        return pesquisar(pesq, 2);
    }

    public List<Pedido> pesquisarPorMes(String pesq) {
        return pesquisar(pesq, 3);
    }

    public List valorPorMes() {

        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Object[].class);
            Root tabela = consulta.from(Pedido.class);

            Expression exprMes = builder.function("month", Integer.class, tabela.get("dataPedido"));
            Expression exprAno = builder.function("year", Integer.class, tabela.get("dataPedido"));

            consulta.multiselect(exprMes, exprAno, builder.sum(tabela.get("valorTotal")));
            consulta.groupBy(exprMes, exprAno);

            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }

    public List valorPorCliente() {

        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Object[].class);
            Root tabela = consulta.from(Pedido.class);

            consulta.multiselect(tabela.get("cliente"), builder.sum(tabela.get("valorTotal")));
            consulta.groupBy(tabela.get("cliente"));

            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }

    public List valorPorFuncionario() {
        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Object[].class);
            Root tabela = consulta.from(Pedido.class);

            consulta.multiselect(tabela.get("funcionario"), builder.sum(tabela.get("valorTotal")));
            consulta.groupBy(tabela.get("funcionario"));

            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }
}
