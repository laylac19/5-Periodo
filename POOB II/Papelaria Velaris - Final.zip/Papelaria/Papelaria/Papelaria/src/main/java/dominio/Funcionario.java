/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;

import gerenciatarefas.FuncoesUteis;
import java.io.Serializable;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author layla
 */
@Entity
public class Funcionario implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idFuncionario;

    @Column(name = "nomeFuncionario", nullable = false)
    private String nome;

    @Column(name = "sobrenomeFuncionario", nullable = false)
    private String sobrenome;

    @Column(length = 1)
    private char sexo;

    @Column(nullable = false, unique = true, updatable = false, length = 14)
    private String cpf;

    @Temporal(TemporalType.DATE)
    private Date dtNasc;

    @Column(length = 14)
    private String celular;

    private float salario;

    @Column(unique = true)
    private String email;

    @OneToMany(mappedBy = "funcionario", fetch = FetchType.LAZY)
    private List<Pedido> pedidos;

    public Funcionario() {
    }

    public Funcionario(String nome, String sobrenome, char sexo, String cpf, Date dtNasc, String celular, float salario, String email) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.sexo = sexo;
        this.cpf = cpf;
        this.dtNasc = dtNasc;
        this.celular = celular;
        this.salario = salario;
        this.email = email;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getDtNasc() {
        return dtNasc;
    }

    public void setDtNasc(Date dtNasc) {
        this.dtNasc = dtNasc;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public String getDtNascFormatada() throws ParseException {
        return FuncoesUteis.dateToStr(dtNasc);
    }

    @Override
    public String toString() {
        return nome;
    }

    public Object[] toArray() throws ParseException {
        NumberFormat formNum = NumberFormat.getCurrencyInstance();
        return new Object[]{this, dtNasc, email, formNum.format(salario)};
    }
}
