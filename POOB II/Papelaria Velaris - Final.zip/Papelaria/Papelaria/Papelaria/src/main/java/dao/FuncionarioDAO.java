/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dominio.Funcionario;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 *
 * @author layla
 */
public class FuncionarioDAO extends GenericDAO {

    private List<Funcionario> pesquisar(String pesq, int tipo) {
        List lista = null;
        Session sessao = null;
        try {
            sessao = ConexaoHibernate.getSessionFactory().openSession();
            sessao.beginTransaction();

            CriteriaBuilder builder = sessao.getCriteriaBuilder();
            CriteriaQuery consulta = builder.createQuery(Funcionario.class);

            Root tabela = consulta.from(Funcionario.class);

            Predicate restricoes = null;
            switch (tipo) {
                case 1:
                    int id = Integer.parseInt(pesq);
                    restricoes = builder.equal(tabela.get("idFuncionario"), id);
                    break;
                case 2:
                    restricoes = builder.like(tabela.get("nome"), pesq + "%");
                    break;
                case 3:
                    restricoes = builder.like(tabela.get("sobrenome"), pesq + "%");
                    break;
            }

            consulta.where(restricoes);
            // EXECUTAR
            lista = sessao.createQuery(consulta).getResultList();

            sessao.getTransaction().commit();
            sessao.close();
        } catch (HibernateException ex) {
            if (sessao != null) {
                sessao.getTransaction().rollback();
                sessao.close();
            }
            throw new HibernateException(ex);
        }
        return lista;
    }

    public List<Funcionario> pesquisarPorId(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 1);
    }

    public List<Funcionario> pesquisarPorNome(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 2);
    }

    public List<Funcionario> pesquisarPorSobrenome(String pesq) throws ClassNotFoundException, SQLException {
        return pesquisar(pesq, 3);
    }
}
