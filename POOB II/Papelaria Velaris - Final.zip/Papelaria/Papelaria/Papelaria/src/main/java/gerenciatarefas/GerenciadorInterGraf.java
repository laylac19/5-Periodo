/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gerenciatarefas;

import dominio.Cliente;
import dominio.Funcionario;
import dominio.Pedido;
import dominio.Produto;
import intergraf.DlgCadCliente;
import intergraf.DlgCadFuncionario;
import intergraf.DlgCadPedido;
import intergraf.DlgCadProduto;
import intergraf.DlgPesqCliente;
import intergraf.DlgPesqFuncionario;
import intergraf.DlgPesqProduto;
import intergraf.DlgRelGroupBy;
import intergraf.FrmPrincipal;
import java.awt.Frame;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author layla
 */
public class GerenciadorInterGraf {

    private FrmPrincipal janPrinc;
    private DlgRelGroupBy janGroupBy;
    
    private DlgCadCliente janCadCliente;
    private DlgCadFuncionario janCadFuncionario;
    private DlgCadPedido janCadPedido;
    private DlgCadProduto janCadProduto;
    
    private DlgPesqCliente janPesqCli;
    private DlgPesqFuncionario janPesqFun;
    private DlgPesqProduto janPesqProduto;

    GerenciadorDominio gerDom;

    public GerenciadorInterGraf() throws SQLException {
        try {
            gerDom = new GerenciadorDominio();
            janPrinc = null;
            janCadCliente = null;
            janCadFuncionario = null;
            janCadPedido = null;
            janCadProduto = null;
            janPesqCli = null;
            janPesqFun = null;
            janPesqProduto = null;
            janGroupBy = null;

        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(janPrinc,
                    "Erro ao conectar com o banco de dados." + ex,
                    "Erro conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(-1);
        }
    }

    public GerenciadorDominio getGerDom() {
        return gerDom;
    }

    private JDialog abrirJanela(java.awt.Frame parent, JDialog dlg, Class classe) {
        if (dlg == null) {
            try {
                dlg = (JDialog) classe.getConstructor(Frame.class, boolean.class,
                        GerenciadorInterGraf.class).newInstance(parent, true, this);
            } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                JOptionPane.showMessageDialog(janPrinc, "Erro ao abrir a janela " + classe.getName());
            }
        }
        dlg.setVisible(true);
        return dlg;
    }

    public void janPrincipal() {
        if (janPrinc == null) {
            janPrinc = new FrmPrincipal(this);
        }
        janPrinc.setVisible(true);
    }

    public void abrirJanCliente() {
        janCadCliente = (DlgCadCliente) abrirJanela(janPrinc, janCadCliente, DlgCadCliente.class);
    }

    public void abrirJanFuncionario() {
        janCadFuncionario = (DlgCadFuncionario) abrirJanela(janPrinc, janCadFuncionario, DlgCadFuncionario.class);
    }

    public void abrirJanPedido() {
        janCadPedido = (DlgCadPedido) abrirJanela(janPrinc, janCadPedido, DlgCadPedido.class);
    }

    public void abrirJanProduto() {
        janCadProduto = (DlgCadProduto) abrirJanela(janPrinc, janCadProduto, DlgCadProduto.class);
    }
    
    public Cliente janPesqCliente() {
        janPesqCli = (DlgPesqCliente) abrirJanela(janPrinc, janPesqCli, DlgPesqCliente.class );
        return janPesqCli.getClienteSelecionado();
    }
    
    public Funcionario janPesqFuncionario() {
        janPesqFun = (DlgPesqFuncionario) abrirJanela(janPrinc, janPesqFun, DlgPesqFuncionario.class );
        return janPesqFun.getFuncionarioSelecionado();
    }
    
    public Produto janPesqProduto(){
        janPesqProduto = (DlgPesqProduto) abrirJanela(janPrinc, janPesqProduto, DlgPesqProduto.class);
        return janPesqProduto.getProdutoSelecionado();
    }
    
    public void janGroupBy(){
        janGroupBy = (DlgRelGroupBy) abrirJanela(janPrinc, janGroupBy, DlgRelGroupBy.class);
    }
    
    public void carregarCombo(JComboBox combo, Class classe) {
        List lista;
        try {
            lista = gerDom.listar(classe);
            combo.setModel( new DefaultComboBoxModel( lista.toArray() )  );
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(janPrinc, 
                    "Erro ao carregar os produtos." + ex,
                    "Erro produto", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) throws SQLException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        GerenciadorInterGraf gerIG = new GerenciadorInterGraf();
        gerIG.janPrincipal();
    }
}
