/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

/**
 *
 * @author layla
 */
@Entity
public class ItemPedido implements Serializable {

    @EmbeddedId
    private ItemPedidoPK chvComposta;

    int qtde;

    public ItemPedido() {
    }

    public ItemPedido(Produto produto, Pedido pedido, int qtde) {
        this.chvComposta = new ItemPedidoPK(produto, pedido);
        this.qtde = qtde;
    }

    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }

    public ItemPedidoPK getChvComposta() {
        return chvComposta;
    }

    public void setChvComposta(ItemPedidoPK chvComposta) {
        this.chvComposta = chvComposta;
    }
}
