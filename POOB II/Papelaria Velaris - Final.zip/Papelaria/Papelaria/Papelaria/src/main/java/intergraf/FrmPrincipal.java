package intergraf;

import gerenciatarefas.GerenciadorInterGraf;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author layla
 */
public class FrmPrincipal extends javax.swing.JFrame {

    private GerenciadorInterGraf gerIG;

    public FrmPrincipal(GerenciadorInterGraf gerIG) {
        this.gerIG = gerIG;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mnuBarraMenu = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        mnuCadCliente = new javax.swing.JMenuItem();
        mnuCadFuncionario = new javax.swing.JMenuItem();
        mnuCadPedido = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        mnuSair = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        mnuClientes = new javax.swing.JMenuItem();
        mnuFuncionarios = new javax.swing.JMenuItem();
        mnuProdutos = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        mnuGroupBy = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema Papelaria Velaris");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/registration.png"))); // NOI18N
        jMenu2.setText("Cadastro");

        mnuCadCliente.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mnuCadCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/customer.png"))); // NOI18N
        mnuCadCliente.setMnemonic('C');
        mnuCadCliente.setText("Clientes");
        mnuCadCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCadClienteActionPerformed(evt);
            }
        });
        jMenu2.add(mnuCadCliente);

        mnuCadFuncionario.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mnuCadFuncionario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/teamwork.png"))); // NOI18N
        mnuCadFuncionario.setMnemonic('F');
        mnuCadFuncionario.setText("Funcionarios");
        mnuCadFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCadFuncionarioActionPerformed(evt);
            }
        });
        jMenu2.add(mnuCadFuncionario);

        mnuCadPedido.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnuCadPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/order.png"))); // NOI18N
        mnuCadPedido.setMnemonic('P');
        mnuCadPedido.setText("Pedidos");
        mnuCadPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCadPedidoActionPerformed(evt);
            }
        });
        jMenu2.add(mnuCadPedido);

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cubes.png"))); // NOI18N
        jMenuItem1.setText("Produtos");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem1);
        jMenu2.add(jSeparator1);

        mnuSair.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_DOWN_MASK));
        mnuSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/log-out.png"))); // NOI18N
        mnuSair.setMnemonic('S');
        mnuSair.setText("Sair");
        jMenu2.add(mnuSair);

        mnuBarraMenu.add(jMenu2);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/seo.png"))); // NOI18N
        jMenu5.setText("Consultas");

        mnuClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/search.png"))); // NOI18N
        mnuClientes.setText("Clientes");
        mnuClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuClientesActionPerformed(evt);
            }
        });
        jMenu5.add(mnuClientes);

        mnuFuncionarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/search.png"))); // NOI18N
        mnuFuncionarios.setText("Funcionários");
        mnuFuncionarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuFuncionariosActionPerformed(evt);
            }
        });
        jMenu5.add(mnuFuncionarios);

        mnuProdutos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/search.png"))); // NOI18N
        mnuProdutos.setText("Produtos");
        mnuProdutos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuProdutosActionPerformed(evt);
            }
        });
        jMenu5.add(mnuProdutos);

        mnuBarraMenu.add(jMenu5);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/monitor.png"))); // NOI18N
        jMenu1.setText("Relatórios");

        mnuGroupBy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/seo-report.png"))); // NOI18N
        mnuGroupBy.setText("GroupBy");
        mnuGroupBy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuGroupByActionPerformed(evt);
            }
        });
        jMenu1.add(mnuGroupBy);

        mnuBarraMenu.add(jMenu1);

        setJMenuBar(mnuBarraMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 488, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 208, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuCadPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCadPedidoActionPerformed
        gerIG.abrirJanPedido();
    }//GEN-LAST:event_mnuCadPedidoActionPerformed

    private void mnuCadClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCadClienteActionPerformed
        gerIG.abrirJanCliente();
    }//GEN-LAST:event_mnuCadClienteActionPerformed

    private void mnuCadFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCadFuncionarioActionPerformed
        gerIG.abrirJanFuncionario();
    }//GEN-LAST:event_mnuCadFuncionarioActionPerformed

    private void mnuClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuClientesActionPerformed
        gerIG.janPesqCliente();
    }//GEN-LAST:event_mnuClientesActionPerformed

    private void mnuFuncionariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuFuncionariosActionPerformed
        gerIG.janPesqFuncionario();
    }//GEN-LAST:event_mnuFuncionariosActionPerformed

    private void mnuProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuProdutosActionPerformed
        gerIG.janPesqProduto();
    }//GEN-LAST:event_mnuProdutosActionPerformed

    private void mnuGroupByActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuGroupByActionPerformed
        gerIG.janGroupBy();
    }//GEN-LAST:event_mnuGroupByActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        gerIG.abrirJanProduto();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JMenuBar mnuBarraMenu;
    private javax.swing.JMenuItem mnuCadCliente;
    private javax.swing.JMenuItem mnuCadFuncionario;
    private javax.swing.JMenuItem mnuCadPedido;
    private javax.swing.JMenuItem mnuClientes;
    private javax.swing.JMenuItem mnuFuncionarios;
    private javax.swing.JMenuItem mnuGroupBy;
    private javax.swing.JMenuItem mnuProdutos;
    private javax.swing.JMenuItem mnuSair;
    // End of variables declaration//GEN-END:variables
}
