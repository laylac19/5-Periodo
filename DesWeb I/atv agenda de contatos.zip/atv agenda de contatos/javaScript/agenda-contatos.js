var botaoAdicionar = document.querySelector("#btnSalvar");

botaoAdicionar.addEventListener("click", function (event) {
    event.preventDefault();

    var form = document.querySelector("#frm");

    var pessoa = adicionarContato(form);
    var erros = validaPessoa(pessoa);


    if (erros.length > 0) {
        exibeMensagensDeErro(erros);
        return;
    }

    preencherTabela(pessoa);

    form.reset();
    var mensagensErro = document.querySelector("#mensagens-erro");
    mensagensErro.innerHTML = "";

});

function preencherTabela(pessoa) {
    var pessoaTr = montaTr(pessoa);
    var tabela = document.querySelector("#tabela-pessoas");
    tabela.appendChild(pessoaTr);
}

function exibeMensagensDeErro(erros) {
    var ul = document.querySelector("#mensagens-erro");

    ul.innerHTML = "";
    erros.forEach(function (erro) {
        var li = document.createElement("li");
        li.textContent = erro;
        ul.appendChild(li);
    });
}

function obtemPessoaDoFormulario(form) {
    var pessoa = {
        nome: form.nome.value,
        telefone: form.telefone.value,
        email: form.email.value
    };

    return pessoa;
}

function montaTr(pessoa) {
    var pessoaTr = document.createElement("tr");
    pessoaTr.classList.add("pessoa");

    pessoaTr.appendChild(montaTd(pessoa.nome, "info-nome"));
    pessoaTr.appendChild(montaTd(pessoa.telefone, "info-telefone"));
    pessoaTr.appendChild(montaTd(pessoa.email, "info-email"));

    return pessoaTr;
}

function montaTd(dado, classe) {
    var td = document.createElement("td");
    td.textContent = dado;
    td.classList.add(classe);
    return td;
}

function validaPessoa(pessoa) {

    var erros = [];

    if (pessoa.nome.length == 0) {
        erros.push("O nome não pode ser em branco");
    }

    if (pessoa.telefone.length == 0) {
        erros.push("O telefone não pode ser em branco");
    }

    if (pessoa.email.length == 0) {
        erros.push("O email não pode ser em branco");
    }

    return erros;
}