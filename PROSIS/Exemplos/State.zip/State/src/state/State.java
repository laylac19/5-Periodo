package state;

public class State {
    public static void main(String[] args) {
        Mario mario = new Mario();

        mario.pegarCogumelo();
        mario.pegarPena();
        mario.levarDano();
        mario.pegarFlor();
        mario.pegarFlor();
        mario.pegarCogumelo();
        mario.levarDano();
        mario.pegarPena();
        mario.levarDano();
        mario.pegarCogumelo();

    }
}
