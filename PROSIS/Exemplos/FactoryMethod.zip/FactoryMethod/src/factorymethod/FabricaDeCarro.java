package factorymethod;
public interface FabricaDeCarro 
{
	Carro criarCarro();
}
