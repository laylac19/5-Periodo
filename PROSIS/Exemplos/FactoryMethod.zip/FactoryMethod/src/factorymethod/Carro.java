package factorymethod;

public interface Carro 
{
	void exibirInfo();
}

