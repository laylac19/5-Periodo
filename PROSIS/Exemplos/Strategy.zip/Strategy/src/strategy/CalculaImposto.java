package strategy;

interface CalculaImposto 
{
	double calculaSalarioComImposto(Funcionario umFuncionario);
}
