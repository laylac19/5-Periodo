package decorator;
public class Cachaca extends Coquetel {
	public Cachaca() {
		nome = "Cachaca";
		preco = 1.5;
	}
}

