package decorator;
public class Rum extends Coquetel {
	public Rum() {
		nome = "Rum";
		preco = 2.5;
	}
}
