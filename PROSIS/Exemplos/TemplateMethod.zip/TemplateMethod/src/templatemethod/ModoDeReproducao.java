package templatemethod;

public enum ModoDeReproducao {
    porNome, porAutor, porAno, porEstrela
}
