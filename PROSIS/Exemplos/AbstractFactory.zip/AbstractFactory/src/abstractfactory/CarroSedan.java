package abstractfactory;

public interface CarroSedan {
	void exibirInfoSedan();
}
