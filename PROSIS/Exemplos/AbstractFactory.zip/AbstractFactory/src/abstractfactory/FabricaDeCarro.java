package abstractfactory;
public interface FabricaDeCarro 
{
    CarroSedan   criarCarroSedan();
    CarroPopular criarCarroPopular();
}
