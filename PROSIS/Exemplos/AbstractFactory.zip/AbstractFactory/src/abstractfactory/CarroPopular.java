package abstractfactory;
public interface CarroPopular {
	void exibirInfoPopular();
}
