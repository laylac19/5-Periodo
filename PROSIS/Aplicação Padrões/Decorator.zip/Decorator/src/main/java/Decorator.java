/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public class Decorator {
    public static void main(String[] args){
        Hardware meuHardware = new ProcessadorI3();
        System.out.println(meuHardware.getNome() + " = R$ " + meuHardware.getPreco());
        
        System.out.println(meuHardware instanceof ProcessadorI3);
        
        meuHardware = new RTX2060(meuHardware);
        System.out.println(meuHardware.getNome() + " = R$ " + meuHardware.getPreco());

    }
}
