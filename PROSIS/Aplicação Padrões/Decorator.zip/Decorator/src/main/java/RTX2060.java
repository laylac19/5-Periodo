/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public class RTX2060 extends HardwareDecorator{
    public RTX2060(Hardware umHardware){
        super(umHardware);
        nome = "RTX2060";
        preco = 2743.50;
    }
}
