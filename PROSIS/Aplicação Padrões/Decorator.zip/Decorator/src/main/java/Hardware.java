/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public class Hardware {
    String nome;
    double preco;

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }
    
}
