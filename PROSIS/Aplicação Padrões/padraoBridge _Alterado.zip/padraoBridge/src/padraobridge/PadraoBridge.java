/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraobridge;

import dispositivos.Dispositivo;
import dispositivos.Radio;
import dispositivos.Televisao;

/**
 *
 * @author 2019122760370
 */
public class PadraoBridge {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        testDevice(new Televisao());
        testDevice(new Radio());
    }

    public static void testDevice(Dispositivo dispositivo) {
        System.out.println("Testes com controle remoto basico");
        ControleRemotoBasico controleBasico = new ControleRemotoBasico(dispositivo);
        controleBasico.onOff();
        dispositivo.mostraStatus();

        System.out.println("Testes com o controle remoto avançado.");
        ControleRemotoAvancado controleAvancado = new ControleRemotoAvancado(dispositivo);
        controleAvancado.onOff();
        controleAvancado.mute();
        dispositivo.mostraStatus();
    }
    
}
