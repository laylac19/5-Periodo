/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraobridge;

import dispositivos.Dispositivo;

/**
 *
 * @author 2019122760370
 */

//Tornar uma classe abstract e os filhos herdam dela
//Trazer as funções para cá

public abstract class ControleRemoto {
    
    protected Dispositivo dispositivo;

    public ControleRemoto(Dispositivo dispositivo) {
        this.dispositivo = dispositivo;
    }

    public void onOff() {
        if (dispositivo.ligado()) {
            dispositivo.desligar();
        } else {
            dispositivo.ligar();
        }
    }

    public void diminuirVolume() {
        dispositivo.setarVolume(dispositivo.pegarVolume() - 10);
    }

    public void aumentarVolume() {
        dispositivo.setarVolume(dispositivo.pegarVolume() + 10);
    }

    public void canalAcima() {
        dispositivo.setarCanal(dispositivo.pegarCanal() + 1);
    }

    public void canalAbaixo() {
        dispositivo.setarCanal(dispositivo.pegarCanal()- 1);
    }
}
