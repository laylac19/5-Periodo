/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraobridge;

import dispositivos.Dispositivo;

/**
 *
 * @author 2019122760370
 */
public class ControleRemotoAvancado extends ControleRemotoBasico{

    public ControleRemotoAvancado(Dispositivo dispositivo) {
        super(dispositivo);
    }
    
    public void mute() {
        System.out.println("Controle remoto: coloque o aparelho no modo mudo");
        dispositivo.setarVolume(0);
    }
}
