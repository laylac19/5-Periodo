/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraobridge;

import dispositivos.Dispositivo;

/**
 *
 * @author 2019122760370
 */
public class ControleRemotoBasico extends ControleRemoto {

    public ControleRemotoBasico(Dispositivo dispositivo) {
        super(dispositivo);
    }

    @Override
    public void canalAbaixo() {
        System.out.println("Remote: voltar um canal");
        super.canalAbaixo(); 
    }

    @Override
    public void canalAcima() {
        System.out.println("Remote: avançar um canal");
        super.canalAcima(); 
    }

    @Override
    public void aumentarVolume() {
        System.out.println("Controle Remoto: aumente o volume");
        super.aumentarVolume(); 
    }

    @Override
    public void diminuirVolume() {
        System.out.println("Controle Remoto: abaixe o volume");
        super.diminuirVolume(); 
    }

    @Override
    public void onOff() {
        System.out.println("Controle remoto: ligue ou desligue");
        super.onOff(); 
    }

    
    
}
