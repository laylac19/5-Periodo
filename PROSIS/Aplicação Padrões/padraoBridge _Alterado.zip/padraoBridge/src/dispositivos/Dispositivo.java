/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dispositivos;

/**
 *
 * @author 2019122760370
 */
public interface Dispositivo {

    public void ligar();

    public void desligar();

    public int pegarVolume();

    public void setarVolume(int volume);

    public int pegarCanal();

    public void setarCanal(int canal);

    public void mostraStatus();

    public boolean ligado();
}
