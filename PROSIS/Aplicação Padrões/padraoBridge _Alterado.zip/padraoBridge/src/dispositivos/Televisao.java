/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dispositivos;

/**
 *
 * @author 2019122760370
 */
public class Televisao implements Dispositivo{
    private boolean ligado = false;
    private int volume = 30;
    private int canal = 1;
    
    @Override
    public void ligar() {
        this.ligado = true;
    }

    @Override
    public void desligar() {
        this.ligado = false;
    }

    @Override
    public int pegarVolume() {
        return volume;
    }

    @Override
    public void setarVolume(int volume) {
        if (volume > 100) {
            this.volume = 100;
        } else if (volume < 0) {
            this.volume = 0;
        } else {
            this.volume = volume;
        }
    }

    @Override
    public int pegarCanal() {
        return canal;
    }

    @Override
    public void setarCanal(int canal) {
        this.canal = canal;
    }

    @Override
    public void mostraStatus() {
        System.out.println("------------------------------------");
        System.out.println("| Eu sou uma televisão.");
        System.out.println("| Eu estou " + (ligado ? "ligado" : "desligado"));
        System.out.println("| O volume atual esta " + volume + "%");
        System.out.println("| O canal atual é " + canal);
        System.out.println("------------------------------------\n");
    }

    @Override
    public boolean ligado() {
        return ligado;
    }
    
}
