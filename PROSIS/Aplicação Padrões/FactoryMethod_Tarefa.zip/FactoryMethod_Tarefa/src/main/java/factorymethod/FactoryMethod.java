/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorymethod;

/**
 *
 * @author doug_
 */
public class FactoryMethod {
    public static void main(String[] args) {
        
        FabricaNotebook fabrica = new FabricaDell();
        Notebook notebook = fabrica.criarNotebook();
        notebook.exibirInfo();
        System.out.println();

        fabrica = new FabricaLenovo();
        notebook = fabrica.criarNotebook();
        notebook.exibirInfo();
        System.out.println();

        fabrica = new FabricaMac();
        notebook = fabrica.criarNotebook();
        notebook.exibirInfo();
        System.out.println();
    }
}
