package factorymethod;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author doug_
 */
public class Lenovo implements Notebook{
    
    @Override
	public void exibirInfo() {
		System.out.println("Modelo: Lenovo IdeaPad \nFabricante: Lenovo");
	}
}
