/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author doug_
 */
public class PadrãoAdapter {
    public static void main(String[] args) {
        Tela tela = new Tela();
        
        CaboVGA cabo = new CaboVGA();
        AdaptadorVGAparaHDMI adaptador = new AdaptadorVGAparaHDMI(cabo);
        
        tela.setCabo_hdmi(adaptador);
        tela.assistir();
        
    }
}
