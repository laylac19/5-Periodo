/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public interface GokuState {
    GokuState virarSS1();
    GokuState virarSS2();        
    GokuState virarSS3();
    GokuState virarSSDeus();
    GokuState Kaioken();
    GokuState voltarNormal();
}
