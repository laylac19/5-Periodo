/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public class State {
    public static void main(String[] args) {
        Goku goku = new Goku();
        goku.virarSS1();
        goku.virarSS2();
        goku.virarSS3();
        goku.virarSSDeus();
        goku.Kaioken();
        goku.voltarNormal();        
    }
}
