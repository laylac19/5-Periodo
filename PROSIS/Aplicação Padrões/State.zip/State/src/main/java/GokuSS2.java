/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public class GokuSS2 implements GokuState {
    
    @Override
    public GokuState voltarNormal() {
        System.out.println("Goku voltou a sua forma normal");
        return new GokuBase();
    }

    @Override
    public GokuState virarSS1() {
        System.out.println("Goku virou Super Sayajin 1");
        return new GokuSS1();
    }

    @Override
    public GokuState virarSS2() {
        System.out.println("Goku já está Super Sayajin 2");
        return this;
    }

    @Override
    public GokuState virarSS3() {
        System.out.println("Goku virou Super Sayajin 3");
        return new GokuSS3();
    }

    @Override
    public GokuState virarSSDeus() {
        System.out.println("Goku virou Super Sayajin Deus");
        return new GokuSSDeus();
    }

    @Override
    public GokuState Kaioken() {
        System.out.println("Goku Super Sayajin 2 com Kaioken");
        return new GokuKaioken();
    }
    
}
