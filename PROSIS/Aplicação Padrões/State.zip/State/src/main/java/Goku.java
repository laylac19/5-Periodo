/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2019122760311
 */
public class Goku {
    protected GokuState forma;
    
    public Goku(){
        forma = new GokuBase();
    }
    
    public void virarSS1(){
        forma = forma.virarSS1();
    }
    
    public void virarSS2(){
        forma = forma.virarSS2();
    }
    
    public void virarSS3(){
        forma = forma.virarSS3();
    }
    
    public void virarSSDeus(){
        forma = forma.virarSSDeus();
    }
    
    public void Kaioken(){
        forma = forma.Kaioken();
    }
    
    public void voltarNormal(){
        forma = forma.voltarNormal();
    }
}
