package templatemethod;

import java.util.ArrayList;

public abstract class OrdenadorTemplate {

    public abstract boolean isPrimeiro(Livro livro1, Livro livro2);

    protected ArrayList<Livro> ordenarLivro(ArrayList<Livro> lista) {
        ArrayList<Livro> novaLista = new ArrayList<Livro>();
        for (Livro livro : lista) {
            novaLista.add(livro);
        }
        for (int i = 0; i < novaLista.size(); i++) {
            for (int j = i; j < novaLista.size(); j++) {
                if (!isPrimeiro(novaLista.get(i), novaLista.get(j))) {
                    Livro temp = novaLista.get(j);
                    novaLista.set(j, novaLista.get(i));
                    novaLista.set(i, temp);
                }
            }
        }

        return novaLista;
    }
}
