package templatemethod;

public class OrdenadorPorAutor extends OrdenadorTemplate {
    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.autor.compareToIgnoreCase(livro2.autor) <= 0) {
            return true;
        }
        return false;
    }
}
