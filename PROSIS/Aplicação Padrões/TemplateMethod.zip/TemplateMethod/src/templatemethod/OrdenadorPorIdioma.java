package templatemethod;

public class OrdenadorPorIdioma extends OrdenadorTemplate {

    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.idioma.compareToIgnoreCase(livro2.idioma) <= 0) {
            return true;
        }
        return false;
    }

}
