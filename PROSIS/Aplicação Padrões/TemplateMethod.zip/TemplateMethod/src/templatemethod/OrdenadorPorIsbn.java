package templatemethod;

public class OrdenadorPorIsbn extends OrdenadorTemplate {

    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.isbn.compareToIgnoreCase(livro2.isbn) <= 0) {
            return true;
        }
        return false;
    }

}
