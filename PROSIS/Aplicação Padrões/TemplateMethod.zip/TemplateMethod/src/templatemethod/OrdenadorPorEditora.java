package templatemethod;

public class OrdenadorPorEditora extends OrdenadorTemplate {
    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.editora.compareToIgnoreCase(livro2.editora) <= 0) {
            return true;
        }
        return false;
    }
}
