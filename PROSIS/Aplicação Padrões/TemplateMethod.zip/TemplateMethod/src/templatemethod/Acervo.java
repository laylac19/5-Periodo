package templatemethod;

import java.util.ArrayList;

public class Acervo {
    protected ArrayList<Livro> livros;
    protected OrdenadorTemplate ordenador;
    public Acervo(ModoDeOrganizacao modo) {
        livros = new ArrayList<Livro>();
        switch (modo) {
            case porTitulo:
                ordenador = new OrdenadorPorTitulo();
                break;
            case porAutor:
                ordenador = new OrdenadorPorAutor();
                break;
            case porEditora:
                ordenador = new OrdenadorPorEditora();
                break;
            case porEdicao:
                ordenador = new OrdenadorPorEdicao();
                break;
            case porAno:
                ordenador = new OrdenadorPorAno();
                break;
            case porQtdePaginas:
                ordenador = new OrdenadorPorQtdePaginas();
                break;
            case porIdioma:
                ordenador = new OrdenadorPorIdioma();
                break;
            case porIsbn:
                ordenador = new OrdenadorPorIsbn();
                break;
            default:
                break;
        }
    }
    public void setModoDeReproducao(ModoDeOrganizacao modo) {
        ordenador = null;
        switch (modo) {
            case porTitulo:
                ordenador = new OrdenadorPorTitulo();
                break;
            case porAutor:
                ordenador = new OrdenadorPorAutor();
                break;
            case porEditora:
                ordenador = new OrdenadorPorEditora();
                break;
            case porEdicao:
                ordenador = new OrdenadorPorEdicao();
                break;
            case porAno:
                ordenador = new OrdenadorPorAno();
                break;
            case porQtdePaginas:
                ordenador = new OrdenadorPorQtdePaginas();
                break;
            case porIdioma:
                ordenador = new OrdenadorPorIdioma();
                break;
            case porIsbn:
                ordenador = new OrdenadorPorIsbn();
                break;
            default:
                break;
        }
    }
    public void adicionarlivro(String titulo, String autor, String editora,
            int edicao, String ano, int qtdePaginas, String idioma, String isbn) {
        livros.add(new Livro(titulo, autor, editora, edicao, ano, qtdePaginas, idioma, isbn));
    }

    public void mostrarListaDeOrganizacao() {
        ArrayList<Livro> novaLista = new ArrayList<Livro>();
        novaLista = ordenador.ordenarLivro(livros);

        for (Livro livro : novaLista) {
            System.out.println(livro.titulo + " - " + livro.autor + 
                    "\n ...................................... " + 
                    "\n Editora: " + livro.editora + 
                    "\n Edicao: " + livro.edicao + 
                    "\n Ano: " + livro.ano + 
                    "\n Qtde de Páginas: " + livro.qtdePaginas + 
                    "\n Idioma: " + livro.idioma + 
                    "\n ISBN: " + livro.isbn + 
                    "\n------------------------------------------------\n");
        }
    }
}
