package templatemethod;

public class OrdenadorPorAno extends OrdenadorTemplate {
    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.ano.compareToIgnoreCase(livro2.ano) <= 0) {
            return true;
        }
        return false;
    }
}
