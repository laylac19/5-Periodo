package templatemethod;

public class OrdenadorPorEdicao extends OrdenadorTemplate {

    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.edicao > livro2.edicao) {
            return true;
        }
        return false;
    }

}
