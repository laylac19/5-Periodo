package templatemethod;

public class Livro {

    String titulo;
    String autor;
    String editora;
    int edicao;
    String ano;
    int qtdePaginas;
    String idioma;
    String isbn;

    public Livro(String titulo, String autor, String editora, int edicao, 
            String ano, int qtdePaginas, String idioma, String isbn) {
        
        this.titulo = titulo;
        this.autor = autor;
        this.editora = editora;
        this.edicao = edicao;
        this.ano = ano;
        this.qtdePaginas = qtdePaginas;
        this.idioma = idioma;
        this.isbn = isbn;
    }
}
