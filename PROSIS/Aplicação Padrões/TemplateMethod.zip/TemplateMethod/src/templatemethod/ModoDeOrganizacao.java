package templatemethod;

public enum ModoDeOrganizacao {
    porTitulo, porAutor, porEditora, porEdicao, porAno, porQtdePaginas, porIdioma, porIsbn
}
