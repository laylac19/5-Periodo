package templatemethod;

public class OrdenadorPorQtdePaginas extends OrdenadorTemplate {

    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.qtdePaginas > livro2.qtdePaginas) {
            return true;
        }
        return false;
    }

}
