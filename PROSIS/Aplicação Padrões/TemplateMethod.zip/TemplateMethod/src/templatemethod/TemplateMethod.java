/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package templatemethod;

/**
 *
 * @author Giovany
 */
public class TemplateMethod {

    public static void main(String[] args) {

        Acervo meuAcervo = new Acervo(ModoDeOrganizacao.porTitulo);
        meuAcervo.adicionarlivro("Corte de Espinhos e Rosas", "Sarah J. Mass", 
                "Galera", 1, "2015", 554, "Portugês", "978-8501105875");
        meuAcervo.adicionarlivro("Corte de Névoa e Fúria", "Sarah J. Mass",
                "Galera", 1, "2016", 920, "Portugês", "978-8501076601");
        meuAcervo.adicionarlivro("Corte de Asas e Ruína", "Sarah J. Mass",
                "Galera", 1, "2017", 721, "Portugês", "978-8501110121");
        meuAcervo.adicionarlivro("Orgulho e Preconceito", "Jane Austen",
                "Martin Claret", 1, "2018", 424, "Portugês", "978-8544001820");
        meuAcervo.adicionarlivro("Harry Potter and the Philosopher's Stone", "J.K. Rowling",
                "Pottermore Publishing", 1, "2015", 345, "Inglês", "978-1408855652");
        meuAcervo.adicionarlivro("Harry Potter and the Prisoner of Azkaban", "J.K. Rowling",
                "Pottermore Publishing", 1, "2019", 480, "Inglês", "978-1526606167");
        meuAcervo.adicionarlivro("Harry Potter e o enigma do Príncipe", "J.K. Rowling",
                "Pottermore Publishing", 1, "2015", 649, "Portugês", "978-8532519474");
       
        System.out.println("\n\n=== Lista por Título ===");
        meuAcervo.mostrarListaDeOrganizacao();

        System.out.println("\n\n=== Lista por Autor ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porAutor);
        meuAcervo.mostrarListaDeOrganizacao();

        System.out.println("\n\n=== Lista por Editora ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porEditora);
        meuAcervo.mostrarListaDeOrganizacao();

        System.out.println("\n\n=== Lista por Edicao ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porEdicao);
        meuAcervo.mostrarListaDeOrganizacao();
        
        System.out.println("\n\n=== Lista por Ano ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porAno);
        meuAcervo.mostrarListaDeOrganizacao();

        System.out.println("\n\n=== Lista por Qtde de Páginas ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porQtdePaginas);
        meuAcervo.mostrarListaDeOrganizacao();

        System.out.println("\n\n=== Lista por Idioma ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porIdioma);
        meuAcervo.mostrarListaDeOrganizacao();

        System.out.println("\n\n=== Lista por ISBN ===");
        meuAcervo.setModoDeReproducao(ModoDeOrganizacao.porIsbn);
        meuAcervo.mostrarListaDeOrganizacao();
    }
}
