package templatemethod;

public class OrdenadorPorTitulo extends OrdenadorTemplate {

    @Override
    public boolean isPrimeiro(Livro livro1, Livro livro2) {
        if (livro1.titulo.compareToIgnoreCase(livro2.titulo) <= 0) {
            return true;
        }
        return false;
    }

}
