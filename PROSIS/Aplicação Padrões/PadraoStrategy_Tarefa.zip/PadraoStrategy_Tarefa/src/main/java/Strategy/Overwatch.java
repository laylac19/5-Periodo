/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strategy;

/**
 *
 * @author doug_
 */
public class Overwatch {
    public static void main(String[] args){
        
        System.out.println("----------------------------------------------------\n");
        Equipe equipeA = new Equipe("A");
        Equipe equipeB = new Equipe("B");
        
        System.out.println("Antes da carga ser ativada ");
        equipeA.setEstrategia(new EstrategiaDeAtaque());
        equipeB.setEstrategia(new EstrategiaDeDefesa());
        
        equipeA.acao();
        equipeB.acao();
        
        System.out.println("---------------------------------------------------\n");
        System.out.println("Depois da carga ser ativada ");
        
        equipeA.setEstrategia(new EstrategiaDeDefesa());
        equipeB.setEstrategia(new EstrategiaDeAtaque());
        
        equipeA.acao();
        equipeB.acao();
    }
}
