/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strategy;

/**
 *
 * @author doug_
 */
public class Equipe {
    
    private Strategy comportamento;
    private String tipo;
    
    public Equipe(String tipo){
        this.tipo = tipo;
    }
    
    public void setEstrategia (Strategy comportamento) {
        this.comportamento = comportamento;
    }
    
    public void acao(){
        System.out.println("Equipe: " + this.tipo);
        comportamento.ComandoDeAcao();
    }
    
}
