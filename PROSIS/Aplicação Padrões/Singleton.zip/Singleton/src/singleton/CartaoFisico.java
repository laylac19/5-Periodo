/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleton;

import java.util.Calendar;
import java.util.Date;



public class CartaoFisico {
    
private long numero;
private String validade;
private String nome;

    private static CartaoFisico instancia;
    public static CartaoFisico getInstancia(String nome){
        if(instancia == null){
            instancia = new CartaoFisico(nome);
        }
        else{
            System.out.println(nome + " Já possui um cartão");
        }
        return instancia;
    }

    public CartaoFisico(String nome1) {
        nome = nome1;
        numero = 5179397342064627l;
        validade = "29/09/2029";
    }

    public long getNumero() {
        return numero;
    }

    public String getValidade() {
        return validade;
    }

    public String getNome() {
        return nome;
    }
    
    
    
}
