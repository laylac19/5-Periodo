/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleton;

/**
 *
 * @author João Kleber
 */
public class Singleton {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CartaoFisico a = CartaoFisico.getInstancia("Joao");
        System.out.println(a.getNome() + " possui o cartão com numero de " + a.getNumero() + " com validade até " + a.getValidade());
        CartaoFisico b = CartaoFisico.getInstancia("Joao");
    }
    
}
